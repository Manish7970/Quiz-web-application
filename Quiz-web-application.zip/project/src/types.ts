export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  points: number;
}

export interface QuizState {
  currentQuestion: number;
  score: number;
  answers: number[];
  isComplete: boolean;
  streak: number;
  timeBonus: number;
}

export interface QuizData {
  questions: Question[];
  title: string;
  description: string;
}