import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Trophy, Timer } from 'lucide-react';

interface QuizStartProps {
  title: string;
  description: string;
  onStart: () => void;
}

export function QuizStart({ title, description, onStart }: QuizStartProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-2xl bg-white rounded-xl shadow-lg p-8 mx-auto text-center"
    >
      <Brain className="w-16 h-16 text-blue-500 mx-auto mb-6" />
      <h1 className="text-3xl font-bold text-gray-800 mb-4">{title}</h1>
      <p className="text-gray-600 mb-8">{description}</p>

      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="p-4 bg-gray-50 rounded-lg">
          <Trophy className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
          <p className="text-sm text-gray-600">Earn Points</p>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <Timer className="w-8 h-8 text-green-500 mx-auto mb-2" />
          <p className="text-sm text-gray-600">Beat the Clock</p>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <Brain className="w-8 h-8 text-purple-500 mx-auto mb-2" />
          <p className="text-sm text-gray-600">Test Knowledge</p>
        </div>
      </div>

      <button
        onClick={onStart}
        className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors duration-200"
      >
        Start Quiz
      </button>
    </motion.div>
  );
}