import React from 'react';
import { motion } from 'framer-motion';
import { Timer, Award, Zap } from 'lucide-react';
import type { Question } from '../types';

interface QuizCardProps {
  question: Question;
  onAnswer: (index: number) => void;
  currentStreak: number;
  timeRemaining: number;
}

export function QuizCard({ question, onAnswer, currentStreak, timeRemaining }: QuizCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="w-full max-w-2xl bg-white rounded-xl shadow-lg p-6 mx-auto"
    >
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center space-x-2">
          <Zap className="w-5 h-5 text-yellow-500" />
          <span className="text-sm font-medium">Streak: {currentStreak}</span>
        </div>
        <div className="flex items-center space-x-2">
          <Timer className="w-5 h-5 text-blue-500" />
          <span className="text-sm font-medium">{timeRemaining}s</span>
        </div>
        <div className="flex items-center space-x-2">
          <Award className="w-5 h-5 text-purple-500" />
          <span className="text-sm font-medium">{question.points} pts</span>
        </div>
      </div>

      <h3 className="text-xl font-semibold text-gray-800 mb-6">{question.question}</h3>

      <div className="grid grid-cols-1 gap-4">
        {question.options.map((option, index) => (
          <button
            key={index}
            onClick={() => onAnswer(index)}
            className="w-full p-4 text-left bg-gray-50 hover:bg-blue-50 rounded-lg transition-colors duration-200 border border-gray-200 hover:border-blue-200"
          >
            <span className="font-medium text-gray-700">{option}</span>
          </button>
        ))}
      </div>
    </motion.div>
  );
}