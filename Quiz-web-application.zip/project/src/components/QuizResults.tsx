import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Star, Clock, Award } from 'lucide-react';
import type { Question } from '../types';

interface QuizResultsProps {
  score: number;
  totalQuestions: number;
  answers: number[];
  questions: Question[];
  timeBonus: number;
  onRestart: () => void;
}

export function QuizResults({ score, totalQuestions, answers, questions, timeBonus, onRestart }: QuizResultsProps) {
  const correctAnswers = answers.filter((answer, index) => answer === questions[index].correctAnswer).length;
  const accuracy = Math.round((correctAnswers / totalQuestions) * 100);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="w-full max-w-2xl bg-white rounded-xl shadow-lg p-8 mx-auto"
    >
      <div className="text-center mb-8">
        <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Quiz Complete!</h2>
        <p className="text-gray-600">Here's how you did</p>
      </div>

      <div className="grid grid-cols-2 gap-6 mb-8">
        <div className="bg-gray-50 p-4 rounded-lg text-center">
          <Star className="w-8 h-8 text-blue-500 mx-auto mb-2" />
          <p className="text-sm text-gray-600">Total Score</p>
          <p className="text-2xl font-bold text-gray-800">{score}</p>
        </div>
        <div className="bg-gray-50 p-4 rounded-lg text-center">
          <Award className="w-8 h-8 text-purple-500 mx-auto mb-2" />
          <p className="text-sm text-gray-600">Accuracy</p>
          <p className="text-2xl font-bold text-gray-800">{accuracy}%</p>
        </div>
        <div className="bg-gray-50 p-4 rounded-lg text-center">
          <Clock className="w-8 h-8 text-green-500 mx-auto mb-2" />
          <p className="text-sm text-gray-600">Time Bonus</p>
          <p className="text-2xl font-bold text-gray-800">+{timeBonus}</p>
        </div>
        <div className="bg-gray-50 p-4 rounded-lg text-center">
          <Trophy className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
          <p className="text-sm text-gray-600">Correct Answers</p>
          <p className="text-2xl font-bold text-gray-800">{correctAnswers}/{totalQuestions}</p>
        </div>
      </div>

      <button
        onClick={onRestart}
        className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors duration-200"
      >
        Try Again
      </button>
    </motion.div>
  );
}