import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import { QuizStart } from './components/QuizStart';
import { QuizCard } from './components/QuizCard';
import { QuizResults } from './components/QuizResults';
import type { QuizData, QuizState } from './types';

const QUESTION_TIMER = 30; // seconds per question
const TIME_BONUS_POINTS = 10; // points per remaining second
const STREAK_MULTIPLIER = 0.5; // bonus multiplier for streaks

const mockQuizData: QuizData = {
  title: "Ultimate Knowledge Challenge",
  description: "Test your knowledge across science, history, art, technology, and more!",
  questions: [
    {
      id: 1,
      question: "Which scientist developed the theory of general relativity?",
      options: ["Isaac Newton", "Albert Einstein", "Niels Bohr", "Stephen Hawking"],
      correctAnswer: 1,
      points: 100
    },
    {
      id: 2,
      question: "In which year did World War II end?",
      options: ["1943", "1944", "1945", "1946"],
      correctAnswer: 2,
      points: 100
    },
    {
      id: 3,
      question: "What is the chemical symbol for gold?",
      options: ["Ag", "Fe", "Au", "Cu"],
      correctAnswer: 2,
      points: 100
    },
    {
      id: 4,
      question: "Which programming language was created by James Gosling?",
      options: ["Python", "Java", "C++", "JavaScript"],
      correctAnswer: 1,
      points: 100
    },
    {
      id: 5,
      question: "What is the largest organ in the human body?",
      options: ["Heart", "Brain", "Liver", "Skin"],
      correctAnswer: 3,
      points: 100
    },
    {
      id: 6,
      question: "Which ancient wonder was located in Alexandria?",
      options: ["The Great Pyramid", "The Lighthouse", "The Hanging Gardens", "The Colossus"],
      correctAnswer: 1,
      points: 100
    },
    {
      id: 7,
      question: "What is the capital of Japan?",
      options: ["Seoul", "Beijing", "Tokyo", "Bangkok"],
      correctAnswer: 2,
      points: 100
    },
    {
      id: 8,
      question: "Who wrote 'Romeo and Juliet'?",
      options: ["William Shakespeare", "Charles Dickens", "Jane Austen", "Mark Twain"],
      correctAnswer: 0,
      points: 100
    },
    {
      id: 9,
      question: "What is the speed of light in kilometers per second (approximate)?",
      options: ["200,000", "300,000", "400,000", "500,000"],
      correctAnswer: 1,
      points: 100
    },
    {
      id: 10,
      question: "Which company developed the first iPhone?",
      options: ["Samsung", "Apple", "Nokia", "Motorola"],
      correctAnswer: 1,
      points: 100
    }
  ]
};

function App() {
  const [quizData, setQuizData] = useState<QuizData | null>(null);
  const [error, setError] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [gameState, setGameState] = useState<QuizState>({
    currentQuestion: -1,
    score: 0,
    answers: [],
    isComplete: false,
    streak: 0,
    timeBonus: 0,
  });
  const [timeRemaining, setTimeRemaining] = useState(QUESTION_TIMER);

  useEffect(() => {
    fetchQuizData();
  }, []);

  useEffect(() => {
    let timer: number;
    if (gameState.currentQuestion >= 0 && !gameState.isComplete && timeRemaining > 0) {
      timer = window.setInterval(() => {
        setTimeRemaining((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [gameState.currentQuestion, gameState.isComplete, timeRemaining]);

  useEffect(() => {
    if (timeRemaining === 0 && !gameState.isComplete) {
      handleAnswer(-1); // Time's up, wrong answer
    }
  }, [timeRemaining]);

  const fetchQuizData = async () => {
    try {
      const response = await fetch('https://api.jsonserve.com/Uw5CrX');
      if (!response.ok) {
        // If the API fails, use mock data
        setQuizData(mockQuizData);
      } else {
        const data = await response.json();
        setQuizData(data);
      }
    } catch (err) {
      // If there's an error, use mock data
      setQuizData(mockQuizData);
    } finally {
      setLoading(false);
    }
  };

  const startQuiz = () => {
    setGameState({
      currentQuestion: 0,
      score: 0,
      answers: [],
      isComplete: false,
      streak: 0,
      timeBonus: 0,
    });
    setTimeRemaining(QUESTION_TIMER);
  };

  const handleAnswer = (answerIndex: number) => {
    if (!quizData) return;

    const currentQ = quizData.questions[gameState.currentQuestion];
    const isCorrect = answerIndex === currentQ.correctAnswer;
    let newStreak = isCorrect ? gameState.streak + 1 : 0;
    let streakBonus = Math.floor(currentQ.points * (newStreak * STREAK_MULTIPLIER));
    let questionScore = isCorrect ? currentQ.points + streakBonus : 0;

    const newState = {
      ...gameState,
      answers: [...gameState.answers, answerIndex],
      score: gameState.score + questionScore,
      streak: newStreak,
    };

    if (gameState.currentQuestion === quizData.questions.length - 1) {
      // Quiz complete - calculate time bonus
      const timeBonus = timeRemaining * TIME_BONUS_POINTS;
      newState.isComplete = true;
      newState.timeBonus = timeBonus;
      newState.score += timeBonus;
    } else {
      newState.currentQuestion += 1;
      setTimeRemaining(QUESTION_TIMER);
    }

    setGameState(newState);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center">
        <div className="text-red-500 bg-white p-4 rounded-lg shadow-lg">{error}</div>
      </div>
    );
  }

  if (!quizData) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 py-8 px-4">
      <AnimatePresence mode="wait">
        {gameState.currentQuestion === -1 && (
          <QuizStart
            key="start"
            title={quizData.title}
            description={quizData.description}
            onStart={startQuiz}
          />
        )}
        {gameState.currentQuestion >= 0 && !gameState.isComplete && (
          <QuizCard
            key="quiz"
            question={quizData.questions[gameState.currentQuestion]}
            onAnswer={handleAnswer}
            currentStreak={gameState.streak}
            timeRemaining={timeRemaining}
          />
        )}
        {gameState.isComplete && (
          <QuizResults
            key="results"
            score={gameState.score}
            totalQuestions={quizData.questions.length}
            answers={gameState.answers}
            questions={quizData.questions}
            timeBonus={gameState.timeBonus}
            onRestart={startQuiz}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;